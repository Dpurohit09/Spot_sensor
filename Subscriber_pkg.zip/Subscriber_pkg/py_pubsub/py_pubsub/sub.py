import rclpy
from rclpy.node import Node

from custom_message.msg import Sensdata        # CHANGE


class MinimalSubscriber(Node):

    def __init__(self):
        super().__init__('minimal_subscriber')
        self.subscription = self.create_subscription(
            Sensdata,                                              # CHANGE
            'sensors',
            self.listener_callback,
            10)
        self.subscription

    def listener_callback(self, msg):
            self.get_logger().info("%s" % msg.time)
            self.get_logger().info('Counter: "%d"' % msg.counter)
            self.get_logger().info('CO2: "%d"' % msg.co2)
            self.get_logger().info('Temperature: "%d"' % msg.temperature)
            self.get_logger().info('H2: "%d"' % msg.r0value)
            self.get_logger().info('LPG: "%d"' % msg.lpg)
            self.get_logger().info('CO: "%d"' % msg.co)
            self.get_logger().info('Smoke: "%d"' % msg.smoke)


def main(args=None):
    rclpy.init(args=args)

    minimal_subscriber = MinimalSubscriber()

    rclpy.spin(minimal_subscriber)

    minimal_subscriber.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()